  import 'dart:io';
  import 'package:flutter/material.dart';
  import 'package:splash_screen_view/SplashScreenView.dart';
  
  
  
  
  import 'package:myapp/src/pages/main/page.dart';
  import 'package:teta_cms/teta_cms.dart';

  ///NOTE:
  ///if you have an error while running <flutter run> 
  ///run <flutter pub upgrade> and than <flutter run --no-sound-null-safety>
  void main() async {
    WidgetsFlutterBinding.ensureInitialized();
    await TetaCMS.initialize(
      token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImYuZS5mYXJpZGVsa2Fib3VzQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJwcm9qZWN0cyI6WzExNTMyMCwxMDY3NjMsMTEzNzM1LDEwMDA5OF0sImltYWdlIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EtL0FPaDE0R2pYTDg3QVNCMW9SNzFGYlBUTnlhMFhpTjZMeEVjdE9wYmhLdVhVb0E9czk2LWMiLCJuYW1lIjoiRmFyaWQgRWxrYWJvdXMiLCJlbWl0dGVyIjoiVGV0YS1BdXRoIiwiaWF0IjoxNjU1NzU0NDcxLCJleHAiOjQ4MTE1MTQ0NzF9.rbpgKaWkqWDx5oSVGMKMEMY2b4UxgnpzRtgE99c7J_E',
      prjId: 113735,
    );
    
    
    
    
    runApp(
      MyApp()
    );
  }
  class MyApp extends StatelessWidget {
    @override
    Widget build(BuildContext context) {
      return MaterialApp(
        title: 'hospitality',
        home: SplashScreenView(
          navigateRoute: PageMain(),
          duration: 2200,
          imageSize: 80,
          imageSrc: 'assets/teta-app.png',
          text: '',
          textType: TextType.NormalText,
          textStyle: TextStyle(
            fontSize: 30.0,
          ),
          backgroundColor: Colors.black,
        ),
      );
    }
  }
  